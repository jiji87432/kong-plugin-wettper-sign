--数据迁移文件，只有当插件 自定义数据库存储 与 通过 daos.lua 定义的 DAO对象 进行交互时，才需要进行迁移，非必须
return {
    "000_base_wettpersign",
}
